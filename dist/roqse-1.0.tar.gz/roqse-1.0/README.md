# ROQSE

**R**educed-**O**rder **Q**uantum **S**cattering **E**mulator

ROQSE makes it easy to build and train a scattering emulator.
