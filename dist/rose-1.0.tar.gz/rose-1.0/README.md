# ROSE

**R**educed-**O**rder **S**cattering **E**mulator

ROSE makes it easy to build and train a scattering emulator.
